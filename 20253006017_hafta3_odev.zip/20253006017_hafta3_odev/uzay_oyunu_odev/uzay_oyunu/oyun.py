def envanter_metni(credits: bool, engines: bool, copilot: bool) -> str:
    """Envanter durumuna göre metin döndürür."""
    parcalar = []
    if credits:
        parcalar.append("bol kredi")
    if engines:
        parcalar.append("güçlü motorlar")
    if copilot:
        parcalar.append("yetenekli bir pilot")

    if not parcalar:
        return ""
    return "Sende: " + ", ".join(parcalar)


def hedef_menusu(hedefler: list[str]) -> str:
    """Numaralandırılmış hedef menüsü döndürür."""
    sonuc = ["Nereye gitmek istersin?"]
    for i, hedef in enumerate(hedefler, start=1):
        sonuc.append(f"[{i}] {hedef}")
    return "\n".join(sonuc)


import json


def galaksi_kur(gezegenler: list, baglantilar: dict, baslangic: str, yakit: int = 50, **kwargs) -> dict:
    """Galaksi verilerini kurar, başlangıç kontrolü yapar."""
    if baslangic not in gezegenler:
        raise ValueError("Başlangıç gezegeni listede yok!")

    return {
        "gezegenler": gezegenler,
        "baglantilar": baglantilar,
        "konum": baslangic,
        "yakit": yakit
    }