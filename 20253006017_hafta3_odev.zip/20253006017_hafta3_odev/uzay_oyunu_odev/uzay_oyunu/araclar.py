import time


def hamle_sayaci():
    """Her çağrıldığında 1 artan bir sayaç döndüren closure fonksiyonu."""
    sayac = 0

    def say():
        nonlocal sayac
        sayac += 1
        return sayac

    return say


def en_bagli_gezegenler(galaksi: dict) -> list:
    """Gezegenleri bağlantı sayısına göre azalan, eşitlikte alfabetik sırayla sıralar."""
    baglantilar = galaksi["baglantilar"]

    sirali = sorted(
        baglantilar.keys(),
        key=lambda gezegen: (-len(baglantilar[gezegen]), gezegen)
    )
    return sirali


def sure_olc(fonk):
    """Bonus: Bir fonksiyonun çalışma süresini ölçen sarmalayıcı (decorator) fonksiyonu."""

    def sarmalayici(*args, **kwargs):
        baslangic = time.time()
        sonuc = fonk(*args, **kwargs)
        bitis = time.time()
        print(f"[{fonk.__name__}] Çalışma süresi: {bitis - baslangic:.5f} saniye")
        return sonuc

    return sarmalayici