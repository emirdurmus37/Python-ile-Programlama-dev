def gorev_kaydi(baslik, *adimlar, oncelik="normal", **ekler):
    """Esnek parametrelerle görev kaydı oluşturur."""
    print(f"[{oncelik.upper()}] {baslik}")

    for sira, adim in enumerate(adimlar, start=1):
        print(f"  {sira}. {adim}")

    for anahtar, deger in ekler.items():
        print(f"  {anahtar}: {deger}")


if __name__ == "__main__":
    gorev_kaydi("Kara deliğe atla", "Kredi kazan", "Pilot bul", "Hiperdrive al", oncelik="yüksek", sorumlu="Ayşe")

    print("-" * 20)

    liste_adimlar = ["Kredi kazan", "Pilot bul", "Hiperdrive al"]
    sozluk_ekler = {"sorumlu": "Ayşe"}
    gorev_kaydi("Kara deliğe atla", *liste_adimlar, oncelik="yüksek", **sozluk_ekler)