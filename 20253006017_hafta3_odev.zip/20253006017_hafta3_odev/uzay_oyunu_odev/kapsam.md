# Görev 4 - Kapsam (Scope) ve Açıklamalar

## 1. Kapsam Örneklerinin Analizi
* **Tahminimiz:** Python'da değişkenler LEGB kuralına (Local, Enclosing, Global, Built-in) göre aranır. Fonksiyon içinde tanımlanan değişkenler yereldir; dışarıdakiler doğrudan değiştirilemez.
* **Gerçek Sonuç:** Fonksiyon içerisinden global bir değişkene atama yapılmaya çalışıldığında Python bu değişkeni yerel olarak algılar ancak değer atanmadan okunmaya çalışıldığı için hata fırlatır.
* **Nedeni:** Python, bir fonksiyon içinde değişkene değer atanıyorsa (`=`) onu otomatik olarak o fonksiyonun yerel (local) alanı olarak kabul eder. 

## 2. UnboundLocalError Açıklaması
Bir fonksiyon içerisinde, globalde tanımlanmış bir değişkeni `global` anahtar kelimesi kullanmadan değiştirmeye veya artırmaya (`x += 1`) kalktığımızda Python **UnboundLocalError** hatası verir. Bunun sebebi, Python'ın o değişkenin yerel olduğunu anlaması fakat daha atama yapılmadan önce değerini okumaya çalışmasıdır. (Ödev kuralları gereği `global` anahtar kelimesi hiçbir görevde kullanılmamıştır.)