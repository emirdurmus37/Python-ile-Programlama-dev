def yakit_ekle(miktar, depo=None):
    if depo is None:
        depo = []
    depo.append(miktar)
    return depo

def test_yakit_ekle():
    sonuc1 = yakit_ekle(10)
    assert sonuc1 == [10]
    sonuc2 = yakit_ekle(20)
    assert sonuc2 == [20]