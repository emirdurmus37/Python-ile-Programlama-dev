from uzay_oyunu.dekoratorler import sure_olc, sinirla, say
from uzay_oyunu.komutlar import KOMUTLAR, komut

def test_sure_olc():
    @sure_olc
    def ornek_fonk(x):
        return x * 2
    sonuc = ornek_fonk(5)
    assert sonuc == 10
    assert ornek_fonk.__name__ == "ornek_fonk"

def test_sinirla():
    @sinirla(0, 100)
    def yakit_harca(miktar):
        return 100 - miktar

    assert yakit_harca(30) == 70
    try:
        yakit_harca(150)
        assert False, "ValueError fırlatmalıydı"
    except ValueError as e:
        assert "0-100 aralığında değil" in str(e)

def test_komut_sistemi():
    durum = {
        "konum": "dunya",
        "baglantilar": ["orion", "karadelik"],
        "credits": 500
    }
    assert "yardim" in KOMUTLAR
    assert "envanter" in KOMUTLAR
    assert "harita" in KOMUTLAR

    fonk, _ = KOMUTLAR["harita"]
    cikti = fonk(durum)
    assert "orion" in cikti