# Dekoratör Sıralaması ve LRU Cache Analizi

Fibonacci fonksiyonu üzerinde yapılan test sonuçları:
1. Yalnızca @say: 21891 çağrı
2. @say üstte, @lru_cache altta: 39 çağrı
3. @lru_cache üstte, @say altta: 21 çağrı

## Neden Farklı Sonuçlar Çıkıyor?
- **Yalnızca @say:** Her özyinelemede (recursion) aynı alt problemler tekrar hesaplandığı için çağrı sayısı üstel olarak artar.
- **@say üstte, @lru_cache altta:** Çağrılar önce `say` sarmalayıcısından geçer, bu yüzden cache'e girmeyen her fiziksel fonksiyon çalışması sayaç tarafından sayılır. Ancak `lru_cache` alt katmanda tekrarlayan sonuçları engellediği için çağrı sayısı ciddi oranda düşer.
- **@lru_cache üstte, @say altta:** Çağrı önce önbelleğe (`lru_cache`) çarpar. Önbellekte olan sonuçlar için fonksiyonun içine hiç girilmez. Bu yüzden sayaç sadece ilk kez hesaplanan benzersiz değerleri sayar ve çağrı sayısı en aza iner. Bu durumda sayaca erişmek için `fib._wrapped.cagri` yöntemi kullanılır.