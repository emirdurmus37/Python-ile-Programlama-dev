from functools import wraps

KOMUTLAR = {}

def komut(ad, aciklama=""):
    def dekorator(func):
        if ad in KOMUTLAR:
            raise ValueError(f"'{ad}' komutu zaten kayıtlı!")
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        KOMUTLAR[ad] = (wrapper, aciklama)
        return wrapper
    return dekorator

@komut("yardim", "komutları listeler")
def komut_yardim(durum):
    cikti = []
    for isim, (_, aciklama) in KOMUTLAR.items():
        cikti.append(f"{isim}: {aciklama}")
    return "\n".join(cikti)

@komut("envanter", "envanter eşyalarını gösterir")
def komut_envanter(durum):
    credits = durum.get("credits", 0)
    engines = durum.get("engines", [])
    return f"Credits: {credits}, Motorlar: {engines}"

@komut("harita", "gidebileceğin gezegenleri gösterir")
def komut_harita(durum):
    gezegenler = durum.get("baglantilar", [])
    return ", ".join(gezegenler)