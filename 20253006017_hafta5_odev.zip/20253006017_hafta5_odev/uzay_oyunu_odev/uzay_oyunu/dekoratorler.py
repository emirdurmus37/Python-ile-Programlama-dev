from functools import wraps
import time



def sure_olc(func):
  @wraps(func)
  def wrapper(*args, **kwargs):
    baslangic = time.perf_counter()
    sonuc = func(*args, **kwargs)
    bitis = time.perf_counter()
    sure = bitis - baslangic
    print(f"{func.__name__}: {sure:.4f} sn")
    return sonuc

  return wrapper




def log_cagri(func):
  @wraps(func)
  def wrapper(*args, **kwargs):
    args_str = ", ".join([repr(a) for a in args])
    kwargs_str = ", ".join([f"{k}={v!r}" for k, v in kwargs.items()])
    tum_arglar = [x for x in [args_str, kwargs_str] if x]
    arg_metin = ", ".join(tum_arglar)

    print(f"-> {func.__name__}({arg_metin})")
    sonuc = func(*args, **kwargs)
    print(f"<<- {func.__name__} {arg_metin}")
    return sonuc

  return wrapper




def sinirla(alt, ust):
  def dekorator(func):
    @wraps(func)
    def wrapper(miktar, *args, **kwargs):
      if not (alt <= miktar <= ust):
        raise ValueError(
            f"{func.__name__}: {miktar} değeri {alt}-{ust} aralığında değil"
        )
      return func(miktar, *args, **kwargs)

    return wrapper

  return dekorator
def say(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        wrapper.cagri += 1
        return func(*args, **kwargs)
    wrapper.cagri = 0
    return wrapper