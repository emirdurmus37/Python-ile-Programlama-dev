from functools import reduce, partial

def gezegen_adlari_map(galaksi: dict) -> list[str]:
    """map kullanarak gezegen adlarının büyük harfli listesi."""
    return list(map(lambda p: p.upper(), galaksi.get("gezegenler", [])))

def gezegen_adlari_liste(galaksi: dict) -> list[str]:
    """Liste üreteci kullanarak gezegen adlarının büyük harfli listesi."""
    return [p.upper() for p in galaksi.get("gezegenler", [])]

def en_az_iki_baglanti_filter(galaksi: dict) -> list[str]:
    """filter kullanarak en az iki bağlantısı olan gezegenler."""
    baglantilar = galaksi.get("baglantilar", {})
    return list(filter(lambda g: len(baglantilar.get(g, [])) >= 2, galaksi.get("gezegenler", [])))

def en_az_iki_baglanti_liste(galaksi: dict) -> list[str]:
    """Liste üreteci kullanarak en az iki bağlantısı olan gezegenler."""
    baglantilar = galaksi.get("baglantilar", {})
    return [g for g in galaksi.get("gezegenler", []) if len(baglantilar.get(g, [])) >= 2]

def toplam_baglanti_reduce(galaksi: dict) -> int:
    """reduce kullanarak toplam bağlantı sayısı."""
    baglantilar = galaksi.get("baglantilar", {})
    uzunluklar = [len(komsular) for komsular in baglantilar.values()]
    if not uzunluklar:
        return 0
    return reduce(lambda x, y: x + y, uzunluklar)

def toplam_baglanti_sum(galaksi: dict) -> int:
    """sum kullanarak toplam bağlantı sayısı."""
    baglantilar = galaksi.get("baglantilar", {})
    return sum(len(komsular) for komsular in baglantilar.values())

# functools.partial ile hız=3 sabit yeni fonksiyon türetme
def yolculuk(mesafe: int, hiz: int) -> float:
    return mesafe / hiz

hizli_yolculuk = partial(yolculuk, hiz=3)

```[cite: 1]

---


1. **Testler (`tests/test_akis.py`):**
   Daha önce oluşturduğunuz veya oluşturacağınız `tests/test_akis.py` dosyası içinde tüm üreteçlerin, boru hatlarının ve `StopIteration` durumlarının test edildiğinden emin olun[cite: 1].
2. **Kapsam / README Dosyası:**
   Ödevde belirtilen Görev 4 kapsamındaki `time.perf_counter()` ölçüm sürelerini ve `cache_info()` çıktılarını projenizdeki **`kapsam.md`** dosyasına ekleyin[cite: 1, 3].
3. **Testlerin Çalıştırılması:**
   PyCharm terminal ekranını açarak tüm testlerin hatasız geçtiğini şu komutla doğrulayın[cite: 2]:
   ```bash
   uv run pytest