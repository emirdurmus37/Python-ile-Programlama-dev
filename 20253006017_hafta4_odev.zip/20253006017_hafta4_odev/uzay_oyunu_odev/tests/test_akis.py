from itertools import islice
from uzay_oyunu.akis import fibonacci


def test_fibonacci_ilk_degerler():
    g = fibonacci()
    assert next(g) == 0
    assert next(g) == 1
    assert next(g) == 1


def test_fibonacci_islice_ve_takewhile():
    ilk_12 = list(islice(fibonacci(), 12))
    assert ilk_12 == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

    kucuk_100 = list(takewhile(lambda x: x < 100, fibonacci()))
    assert all(x < 100 for x in kucuk_100)


def test_fibonacci_tek_kullanimlik():
    g = fibonacci()
    ilk_liste = list(islice(g, 5))
    ikinci_liste = list(islice(g, 5))
    assert ilk_liste != ikinci_liste